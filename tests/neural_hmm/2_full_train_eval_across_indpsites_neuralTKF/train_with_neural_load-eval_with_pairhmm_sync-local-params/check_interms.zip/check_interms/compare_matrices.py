#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 30 15:56:47 2025

@author: annabel
"""
import numpy as np
import pickle

def read_mat(file):
    with open(file,'rb') as f:
        return np.load(file)

### transitions
true = read_mat('RESULTS_nonlocal_params/out_arrs/PARAMS-MAT_test-set_pt0_conditional_prob_transit_matrix.npy')
loaded = read_mat('RESULTS_params_from_nonlocal/out_arrs/PARAMS-MAT_test-set_pt0_conditional_prob_transit_matrix.npy')
assert np.allclose(loaded, true)
del true, loaded


### emissions at match (different formats)
true_neural = read_mat('RESULTS_nonlocal_params/out_arrs/PARAMS-MAT_test-set_pt0_cond_prob_emit_at_match.npy')
loaded_pairhmm = read_mat('RESULTS_params_from_nonlocal/out_arrs/PARAMS-MAT_test-set_pt0_cond_prob_emit_at_match.npy')

# check diags
pairhmm_diags = np.diagonal(loaded_pairhmm, axis1=1, axis2=2)
assert np.allclose(pairhmm_diags, true_neural[...,0])
del pairhmm_diags

# check off-diags where i != j
T = true_neural.shape[0]
A = true_neural.shape[1]
for t in range(T):
    for i in range(A):
        for j in range(A):
            if i != j:
                true = true_neural[t,j,1]
                pred = loaded_pairhmm[t, i, j]
                assert np.allclose(true, pred)
