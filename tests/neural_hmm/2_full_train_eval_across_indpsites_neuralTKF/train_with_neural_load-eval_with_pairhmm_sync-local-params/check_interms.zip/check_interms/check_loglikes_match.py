#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 30 17:02:10 2025

@author: annabel
"""
import numpy as np

def load_mat(file):
    with open(file,'rb') as f:
        return np.load(f)

neural_loglikes = load_mat('EVAL_nonlocal_params/logfiles/NP-MAT_test-dset_pt0_FINAL-LOGLIKES.npy')
pairhmm_loglikes = load_mat('RESULTS_params_from_nonlocal/logfiles/NP-MAT_test-set_pt0_FINAL-LOGLIKES.npy')

neural_cond = neural_loglikes[:, 1]
pairhmm_cond = pairhmm_loglikes[:, 2]

print( np.allclose(neural_cond, pairhmm_cond) )
