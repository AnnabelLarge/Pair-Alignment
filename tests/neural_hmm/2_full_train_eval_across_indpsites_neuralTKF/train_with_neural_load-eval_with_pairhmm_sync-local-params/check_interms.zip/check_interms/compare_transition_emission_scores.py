#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 30 16:41:57 2025

@author: annabel
"""
import pickle
import numpy as np

def load_mat(file):
    with open(file,'rb') as f:
        return np.load(f)

def load_dict(file):
    with open(file,'rb') as f:
        return pickle.load(f)


neural_e = load_mat("neural_e.npy")
neural_score_per_pos = load_mat("neural_score_per_pos.npy")
neural_tr_AFTER_corr = load_mat("neural_tr_AFTER_corr.npy")
pairhmm_joint_intermeds = load_dict("from-pairhmm_joint-loglike-intermeds.pkl")
pairhmm_anc_marg_intermeds = load_dict("from-pairhmm_anc-marg-loglike-intermeds.pkl")

pairhmm_joint_tr = np.array(pairhmm_joint_intermeds['joint_transit_score'])
pairhmm_joint_e = np.array(pairhmm_joint_intermeds['joint_emission_score'])
del pairhmm_joint_intermeds

pairhmm_anc_marg_tr = np.array(pairhmm_anc_marg_intermeds['anc_marg_transit_score'])
pairhmm_anc_marg_e = np.array(pairhmm_anc_marg_intermeds['anc_marg_emit_score'])
del pairhmm_anc_marg_intermeds


### predicted
pred_tr  = pairhmm_joint_tr - pairhmm_anc_marg_tr
pred_e  = pairhmm_joint_e - pairhmm_anc_marg_e


### true transition and emissions
true_tr = neural_tr_AFTER_corr.sum(axis=-1)
true_e = neural_e.sum(axis=-1)
new_order = [2, 5, 4, 7, 3, 8, 0, 1, 6]
true_tr = true_tr[new_order]
true_e = true_e[new_order]

print(f'Transitions: {np.allclose(true_tr, pred_tr)}')
print(f'Emissions: {np.allclose(true_e, pred_e)}')

