#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May  6 14:15:49 2025

@author: annabel
"""
import numpy as np
import pandas as pd
import re

in_file = f'one-GTR_PF07734_final_params.eg'
out_prefix = f'one-GTR_PF07734'
aas_in_order = list('ACDEFGHIKLMNPQRSTVWY')
aas_in_order.sort()
aas_in_order = ''.join(aas_in_order)


def extract_float(line):
    patt = r"\(prob ([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\)"
    return float(re.search(patt, line).group(1))

def impute_exchanges(Q, pi):
    exch = np.zeros((20,20))
    for i in range(20):
        for j in range(20):
            if i != j:
                exch[i,j] = Q[i,j] / pi[j]
    assert np.allclose( exch, exch.T )
    assert (exch >= 0).all()
    
    return exch

def add_diags(Q):
    neg_row_sums = -Q.sum(axis=1)
    diags_to_add = np.einsum('ij,i->ij', np.eye(20), neg_row_sums)
    out = diags_to_add + Q
    return out
    

with open(in_file,'r') as f:
    conts = f.read()
del f


### parse file
# find equilibrium probabilities
equl_patt = ('\(initial \(state \(([a-z])\)\) '+
             '\(prob ([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\)\)')
raw_out = re.findall(equl_patt, conts)
equl_dist = {}
for aa, prob in raw_out:
    aa = aa.upper()
    prob = float(prob)
    equl_dist[aa] = prob
del equl_patt, raw_out, aa, prob

# find rates
rates_patt = ('\(mutate \(from \(([a-z])\)\) \(to \(([a-z])\)\) '+
              '\(rate ([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\)\)')
raw_out = re.findall(rates_patt, conts)
rates = {}
for aa_from, aa_to, rate in raw_out:
    aa_from = aa_from.upper()
    aa_to = aa_to.upper()
    key = f'{aa_from}_{aa_to}'
    rate = float(rate)
    rates[key] = rate
del rates_patt, raw_out, aa_from, aa_to, rate, key

# match vs not match probs
to_end_prob_line = [l for l in conts.split('\n') if 
                    '(transform (from (S0*)) (to ()) (prob' in l][0]
to_end_prob = extract_float(to_end_prob_line)
del to_end_prob_line

to_emit_prob_line = [l for l in conts.split('\n') if 
                    ' (transform (from (S0*)) (to (S0)) (prob' in l][0]
to_emit_prob = extract_float(to_emit_prob_line)

print(f'Probability sum: {to_end_prob + to_emit_prob}')


### write_parameters
# given by xrate
equl_to_write = np.zeros((20,))
Q_raw = np.zeros((20,20))
for i,aa_from in enumerate( aas_in_order ): 
    equl_to_write[i] = equl_dist[aa_from]
    
    for j,aa_to in enumerate( aas_in_order ):
        key = f'{aa_from}_{aa_to}'
        Q_raw[i,j] = rates.get(key, 0)

assert (Q_raw >= 0).all()
assert (equl_to_write >= 0).all()
assert np.allclose(equl_to_write.sum(), 1)
        

# row normalize Q
Q_unnormed = add_diags(Q_raw)
del Q_raw

assert np.allclose( Q_unnormed.sum(axis=1), 0 )

global_subs_rate = 0
for i in range(20):
    global_subs_rate += Q_unnormed[i,i] * equl_to_write[i]
global_subs_rate = -global_subs_rate
print(f'global rho: {global_subs_rate}')

Q_normed = Q_unnormed / global_subs_rate

assert np.allclose( Q_normed.sum(axis=1), 0 )



# impute exchangeabilities 
exch_unnormed = impute_exchanges(Q = Q_unnormed, 
                                 pi = equl_to_write)

exch_normed = impute_exchanges(Q = Q_normed, 
                               pi = equl_to_write)


checkmat1 = add_diags( np.einsum('ij,j->ij', exch_normed, equl_to_write) )
assert np.allclose( checkmat1, Q_normed )

checkmat2 = add_diags( np.einsum('ij,j->ij', exch_unnormed, equl_to_write) )
assert np.allclose( checkmat2, Q_unnormed )

assert np.allclose( global_subs_rate * checkmat1, checkmat2 )
del checkmat1, checkmat2


### write
with open(f'PARAM-MAT_{out_prefix}_xrate_fitted_equlibriums.npy','wb') as g:
    np.save(g, equl_to_write)
    
out_df = pd.DataFrame(equl_to_write, index=list(aas_in_order) )
out_df.to_csv(f'PARAMS_{out_prefix}_xrate_fitted_equlibriums.tsv',
              sep='\t')
del out_df, equl_to_write

with open(f'PARAM-MAT_{out_prefix}_xrate_fitted_unit_norm_Q.npy','wb') as g:
    np.save(g, Q_normed )
    
out_df = pd.DataFrame(Q_normed, index=list(aas_in_order), columns=list(aas_in_order) )
out_df.to_csv(f'PARAMS_{out_prefix}_xrate_fitted_unit_norm_Q.tsv',
              sep='\t')
del out_df, Q_normed

with open(f'PARAM-MAT_{out_prefix}_xrate_fitted_exchanges_unit_norm_Q.npy','wb') as g:
    np.save(g, exch_normed)

out_df = pd.DataFrame(exch_normed, index=list(aas_in_order), columns=list(aas_in_order) )
out_df.to_csv(f'PARAMS_{out_prefix}_xrate_fitted_exchanges_unit_norm_Q.tsv',
              sep='\t')
del out_df, exch_normed

with open(f'PARAM-MAT_{out_prefix}_xrate_fitted_unnormed_Q.npy','wb') as g:
    np.save(g, Q_unnormed )
    
out_df = pd.DataFrame(Q_unnormed, index=list(aas_in_order), columns=list(aas_in_order) )
out_df.to_csv(f'PARAMS_{out_prefix}_xrate_fitted_unnormed_Q.tsv',
              sep='\t')
del out_df, Q_unnormed

with open(f'PARAM-MAT_{out_prefix}_xrate_fitted_exchanges_unnormed_Q.npy','wb') as g:
    np.save(g, exch_unnormed)
    
out_df = pd.DataFrame(exch_unnormed, index=list(aas_in_order), columns=list(aas_in_order) )
out_df.to_csv(f'PARAMS_{out_prefix}_xrate_fitted_exchanges_unnormed_Q.tsv',
              sep='\t')
del out_df, exch_unnormed

to_save = np.array([to_emit_prob, to_end_prob])
with open(f'PARAM-MAT_{out_prefix}_geom_length_params.npy','wb') as g:
    np.save(g, to_save)
del to_save

with open(f'PARAMS_{out_prefix}_geom_length_params.txt','w') as g:
    g.write(f'P(END): {to_end_prob}\n')
    g.write(f'1-P(END): {to_emit_prob}\n')
    g.write(f'global subs rate, rho: {global_subs_rate}\n')

