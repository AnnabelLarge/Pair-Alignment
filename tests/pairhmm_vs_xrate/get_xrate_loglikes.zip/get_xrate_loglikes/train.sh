./xrate -rndseed 1 \
-logcopy xrate_testrun.log \
--grammar nullprot_no_gaps.eg  \
--train xrate_final_params.txt \
--training-log xrate_params_per_iter.log \
--maxscore \
--score \
--branch-min 1e-10 \
--forgive 20 \
PF07734_cherry-pairs-only-match.seed > xrate_score_per_sample.gff
