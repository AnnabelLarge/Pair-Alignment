#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May  6 18:01:23 2025

@author: annabel
"""
import numpy as np
import pandas as pd

in_file = f'one-GTR_PF07734_score_per_sample.gff'

with open(in_file,'r') as f:
    conts = f.read()
del f

conts = conts.split('//\n')

pairs = []
max_scores = []
sum_scores = []
for entry in conts:
    for line in entry.split('\n'):
        if line.startswith('#=GF ID'):
            pair_id = line.strip().split()[-1]
            pairs.append(pair_id)
        
        elif line.startswith('#=GF SC_max_nullprot'):
            max_loglike_bits = float( line.strip().split()[-2] )
            max_scores.append(max_loglike_bits)
        
        elif line.startswith('#=GF SC_sum_nullprot'):
            sum_loglike_bits = float( line.strip().split()[-2] )
            sum_scores.append(sum_loglike_bits)

if not np.allclose(max_scores, sum_scores):
    print('mismatch between max and sum')
del max_loglike_bits, sum_scores, entry, line, pair_id, sum_loglike_bits

results = pd.DataFrame({'pair': pairs,
                        'inside_loglike_bits': max_scores})

results.to_csv(in_file.replace('.gff','_parsed.tsv'), sep='\t')