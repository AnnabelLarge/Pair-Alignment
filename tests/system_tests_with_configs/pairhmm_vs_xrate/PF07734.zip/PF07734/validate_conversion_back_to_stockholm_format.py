#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 14 15:19:27 2025

@author: annabel

make sure encoding was correct....
"""

### load reference alignment
ref_file = 'PF07734.seed'

ref_seqs_gapped = {}
with open(ref_file,'r') as f:
    for line in f:
        if not line.startswith('#'):
            line = line.strip().split()
            assert line[0] not in ref_seqs_gapped.keys()
            ref_seqs_gapped[line[0]] = line[1]


### load my cherries
my_seed_file = 'PF07734_cherry-pairs-only-match.seed'

with open(my_seed_file, 'r') as f:
    conts = f.read().split('//\n')
conts = [elem for elem in conts if len(elem) > 0]

for align in conts:
    align = [line for line in align.split('\n') if not line.startswith('#') and len(line) > 0]
    seq1_name, seq1_match_only = align[0].strip().split()
    seq2_name, seq2_match_only = align[1].strip().split()
    
    ref_seq1_gapped = ref_seqs_gapped[seq1_name.replace('/match-only','')]
    ref_seq2_gapped = ref_seqs_gapped[seq2_name.replace('/match-only','')]
    
    ref_seq1_match_pos_only = ''
    ref_seq2_match_pos_only = ''
    for i in range(len(ref_seq1_gapped)):
        seq1_tok = ref_seq1_gapped[i]
        seq2_tok = ref_seq2_gapped[i]
        if (seq1_tok != '.') and (seq2_tok != '.'):
            ref_seq1_match_pos_only += seq1_tok
            ref_seq2_match_pos_only += seq2_tok
    
    assert ref_seq1_match_pos_only == seq1_match_only
    assert ref_seq2_match_pos_only == seq2_match_only

print("[PASS] matches reference file from pfam!")

