#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 13 11:55:20 2025

@author: annabel
"""
import numpy as np
import pandas as pd

prefix = f'PF07734'

### checksum with total number of indel positions
df = pd.read_csv(f'{prefix}_metadata.tsv', sep='\t')
total_indel_positions = df['num_ins'] + df['num_del']
total_indel_positions = total_indel_positions.to_numpy().sum()
del df


### observed counts across all positions
with open(f'{prefix}_seqs_unaligned.npy','rb') as f:
    mats = np.load(f)

toks, counts = np.unique(mats, return_counts=True)
arrs = np.stack([toks, counts])
arrs_cut = arrs[:,arrs[0,:]>=3]
sorted_indices = np.argsort(arrs_cut[0, :])   # sort based on first row
arrs_sorted = arrs_cut[:, sorted_indices]
aas_all_positions = arrs_sorted[1,:]

del mats, toks, counts, arrs, arrs_cut, sorted_indices, f, arrs_sorted


### observed counts in just match positions
with open(f'{prefix}_subCounts.npy','rb') as f:
    mats = np.load(f).sum(axis=0)

anc_counts = mats.sum(axis=0)
desc_counts = mats.sum(axis=1)
aas_match_positions = anc_counts + desc_counts

del mats, anc_counts, desc_counts, f


diff = aas_all_positions - aas_match_positions
assert np.allclose( diff.sum(), total_indel_positions)
del diff


with open(f'{prefix}_AAcounts.npy','wb') as g:
    np.save(g, aas_all_positions)

with open(f'{prefix}_AAcounts_subsOnly.npy','wb') as g:
    np.save(g, total)