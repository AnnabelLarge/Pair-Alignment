#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 13 18:31:57 2025

@author: annabel
"""
import numpy as np
import pandas as pd


prefix = 'PF07734'



with open(f'{prefix}_subCounts.npy','rb') as f:
    mat = np.load(f)

num_match_pos = mat.sum(axis=(-2,-1))
num_exact_match = np.trace(mat, axis1=-2, axis2=-1)

df = pd.read_csv(f'{prefix}_metadata.tsv',
                 sep='\t',
                 index_col=0)

assert np.allclose(df['num_matches'], num_match_pos)

df['num_exact_matches'] = num_exact_match
df['num_subs'] = num_match_pos - num_exact_match

df.to_csv(f'AMENDED_{prefix}_metadata.tsv', sep='\t')

