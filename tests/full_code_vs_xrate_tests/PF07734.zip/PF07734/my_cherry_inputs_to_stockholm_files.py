#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May  5 20:40:31 2025

@author: annabel


About:
======
Given my input matrices, convert to stockholm format with newick trees
"""
import numpy as np
import pandas as pd
from tqdm import tqdm

prefix = 'PF07734'
min_branch_length = 1e-10
out_file = f'{prefix}_cherry-pairs-only-match.seed'
aas_in_order = np.array( list('ACDEFGHIKLMNPQRSTWYV') )


### load data
aligned_mat_file = f'{prefix}_aligned_mats.npy'
with open(aligned_mat_file,'rb') as f:
    aligned_mat = np.load(f)
del f, aligned_mat_file

meta_df = pd.read_csv(f'{prefix}_metadata.tsv', sep='\t', index_col=0)

# make sure information matches, based on sequence lengths
align_lens = (aligned_mat[...,0] != 0).sum(axis=1)
assert np.allclose(align_lens-2, meta_df['alignment_len'])

anc_mask = ~np.isin( aligned_mat[...,0], np.array([0,1,2,43]) )
anc_lens = anc_mask.sum(axis=1)
assert np.allclose(anc_lens, meta_df['anc_seq_len'])

desc_mask = ~np.isin( aligned_mat[...,1], np.array([0,1,2,43]) )
desc_lens = desc_mask.sum(axis=1)
assert np.allclose(desc_lens, meta_df['desc_seq_len'])
del align_lens, anc_mask, anc_lens, desc_mask, desc_lens


all_entries = []
for b in tqdm( range(aligned_mat.shape[0]) ):
    ### construct trees, get names
    row = meta_df.iloc[b]
    alignment_id = row['pairID']
    pfam_name = row['pfam']
    anc_name = row['ancestor']+'/match-only'
    desc_name = row['descendant']+'/match-only'
    full_t = row['TREEDIST_anc-to-desc']
    anc_t = min_branch_length
    desc_t = full_t - min_branch_length
    tree_str = f'({anc_name}:{anc_t},{desc_name}:{desc_t});'
    del row, full_t, anc_t, desc_t
    
    ### construct text alignments
    a = aligned_mat[b,...,[0,1]]
    mask = ~np.isin(a, np.array([0,1,2,43]) )
    match_pos_mask = mask.sum(axis=0)
    a_masked = a[ :, (match_pos_mask==2) ]-3
    a_str = aas_in_order[a_masked]
    anc_str = ''.join( a_str[0,...].tolist() )
    desc_str = ''.join( a_str[1,...].tolist() )
    del mask, match_pos_mask, a_masked, a_str
    
    # uncomment to check by loop
    check_anc = ''
    check_desc = '' 
    for l in range(a.shape[1]):
        anc = a[0,l]
        desc = a[1,l]
        assert anc in range(44)
        assert desc in range(44)
        
        if (anc not in [0,1,2,43]) and (desc not in [0,1,2,43]):
            anc_idx = anc-3
            desc_idx = desc-3
            
            assert anc_idx in range(20)
            assert desc_idx in range(20)
            
            check_anc += aas_in_order[anc_idx] 
            check_desc += aas_in_order[desc_idx] 
    
    assert check_anc == anc_str
    assert check_desc == desc_str
    
    del l, anc, desc, anc_idx, desc_idx, check_anc, check_desc
    del a
    
    if anc_str == desc_str:
        alignment_id = alignment_id + '_same-seq'
    
    
    ### make a stockholm formatted entry
    entry = (f'# STOCKHOLM 1.0\n'+
             f'#=GF ID {alignment_id}\n'+
             f'#=GF AC {pfam_name}\n'+
             f'#=GF NH {tree_str}\n'+
             f'{anc_name}    {anc_str}\n'+
             f'{desc_name}    {desc_str}\n'+
             f'//')
    
    all_entries.append(entry)
    
    del alignment_id, pfam_name, tree_str, anc_str, desc_str
    del anc_name, desc_name, b, entry

all_entries = '\n'.join(all_entries) + '\n'


### save file
with open(out_file,'w') as g:
    g.write(all_entries)
    
    
